import matplotlib.pyplot as mpl

mpl.plot([0, 1, 2], [10, 3, 7], ".")